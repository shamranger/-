Weights can be downloaded from pytorch torchvision.models https://pytorch.org/vision/0.8/models.html
